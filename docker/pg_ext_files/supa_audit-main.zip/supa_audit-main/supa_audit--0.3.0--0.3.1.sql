select pg_catalog.pg_extension_config_dump('audit.record_version', '');
select pg_catalog.pg_extension_config_dump('audit.record_version_id_seq', '');
