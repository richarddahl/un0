alter table audit.record_version alter column ts set default (now());
